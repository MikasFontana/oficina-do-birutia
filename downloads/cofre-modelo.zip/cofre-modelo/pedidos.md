# Pedidos prontos, na ordem

Cole cada um na sua IA, com a pasta do cofre conectada. Troque o que estiver entre colchetes.

## 1. Entender o cofre
Leia a estrutura desta pasta e o arquivo LEIA-ME.md. Depois me explique, em palavras simples, o que cada pasta guarda e onde você vai registrar cada tipo de coisa. Não crie nem mova nada ainda.

## 2. Combinar a regra de registro
Quero que, ao fim de todo trabalho relevante que fizermos juntos, você registre no cofre: (1) o diário do dia em 50-Diario, com o modelo Diário; (2) a nota de status do projeto em 10-Projetos; (3) uma nota de aprendizado em 30-Conhecimento para cada ideia que vale reaproveitar. Depois, avise em UMA linha o que registrou. Nunca apague nada: se algo ficar velho, mova para 90-Arquivo. Se faltar informação, escreva "a confirmar".

## 3. Processar a entrada
Leia tudo que está em 00-Entrada. Para cada arquivo: descubra a que projeto ele pertence, crie ou atualize a nota do projeto, extraia os aprendizados em notas curtas e mova o original para a pasta do projeto. No fim, me mostre uma lista do que foi feito e do que ficou em dúvida. Não invente nada.

## 4. Atualização semanal de cada projeto (para agendar)
Resuma o que aconteceu neste projeto desde a última atualização: o que foi feito, o que mudou, decisões novas com o motivo e os próximos passos. Entregue como um arquivo Markdown chamado "Atualização - [nome do projeto] - [data].md" para eu colocar em 00-Entrada. Não inclua senhas nem dados pessoais de terceiros.

## 5. Onde paramos?
Leia o diário dos últimos 7 dias e a nota de status de cada projeto ativo. Me diga, projeto por projeto, em no máximo duas linhas: onde paramos e qual é o próximo passo. Termine com a pendência mais antiga.
