Uma pasta por projeto. Dentro, uma nota de status com o mesmo nome da pasta.
