# Cofre modelo · Oficina do Biruta

Uma pasta de notas que a sua IA lê e atualiza. Funciona no Obsidian (grátis) e em qualquer ferramenta de IA que leia arquivos da sua pasta.

## Como usar
1. Instale o Obsidian (obsidian.md/download).
2. Copie esta pasta para um lugar fixo, por exemplo Documentos, e renomeie para o nome que quiser (ex.: Cofre).
3. No Obsidian: **Abrir pasta como cofre** e escolha esta pasta.
4. Abra a nota **Início**.
5. Conecte a pasta à sua IA (Claude Code, Cowork ou outra) e cole os pedidos do arquivo **pedidos.md**, na ordem.

## O que cada pasta guarda
- **00-Entrada**: o que chegou e ainda não foi organizado (resumos, links, ideias soltas).
- **10-Projetos**: uma pasta por projeto, com uma nota de status.
- **30-Conhecimento**: aprendizados curtos, uma ideia por nota, ligados entre si.
- **50-Diario**: uma nota por dia, com o que foi feito e os próximos passos.
- **90-Arquivo**: o que terminou.
- **_modelos**: moldes das notas.

## Cuidados
- Não guarde senhas, chaves ou dados sensíveis de terceiros.
- Faça backup da pasta.
- Arquivos pesados (vídeo, imagem) ficam fora do cofre. Guarde só o caminho deles.
