Uma nota por dia, criada pelo modelo Diário.
