---
tipo: painel
---
# Início

> [!tip] Como usar
> - Jogue qualquer material bruto em **00-Entrada** (resumo, link, print, ideia solta). A IA organiza.
> - Nota nova com modelo: Ctrl + P, depois **Modelos: Inserir modelo**.
> - Diário do dia: ícone de calendário na barra lateral.
> - Pergunte à IA: **onde paramos?**

## Projetos ativos
- [[10-Projetos]]

## Conhecimento
- [[30-Conhecimento]]

## Hoje
- [[50-Diario]]
