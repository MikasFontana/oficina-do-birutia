Jogue aqui o material bruto. A IA organiza e move para o lugar certo.
