Um aprendizado por nota, curto, ligado a outras notas com [[colchetes]].
