---
tipo: projeto
status: ativo
inicio: {{date}}
tags: [projeto]
---
# {{title}}

## Objetivo
[o que precisa ser entregue e para quê]

## Situação agora
[onde o projeto está hoje]

## Decisões
- {{date}}: [o que foi decidido e por quê]

## Próximos passos
- [ ] 

## Aprendizados
[o que funcionou ou não; vira nota em 30-Conhecimento]
