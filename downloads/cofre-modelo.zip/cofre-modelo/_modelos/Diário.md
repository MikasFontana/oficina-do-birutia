---
tipo: diario
data: {{date}}
tags: [diario]
---
# {{date}}

## O que foi feito

## Decisões

## Aprendizados

## Próximos passos
- [ ] 
