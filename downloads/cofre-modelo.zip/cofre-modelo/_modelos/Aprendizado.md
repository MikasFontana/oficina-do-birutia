---
tipo: aprendizado
area:
criado: {{date}}
tags: [aprendizado]
---
# {{title}}

## A ideia em uma frase

## Como aplicar

## Exemplo real
[projeto onde foi usado, com link]

## Ligações
- Relacionada a: 
- Origem: 
