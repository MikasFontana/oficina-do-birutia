---
tipo: reuniao
data: {{date}}
tags: [reuniao]
---
# Reunião {{title}}

## Quem participou

## Pontos principais

## Decisões

## Próximos passos
- [ ] 
