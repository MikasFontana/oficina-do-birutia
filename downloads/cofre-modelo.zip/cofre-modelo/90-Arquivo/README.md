O que terminou. Nada é apagado, só movido para cá.
