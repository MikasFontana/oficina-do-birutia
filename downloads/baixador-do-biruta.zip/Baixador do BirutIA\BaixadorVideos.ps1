﻿param([switch]$SemJanela, [switch]$ForcarAjuste)
# Baixador de Vídeos (tela de vidro). A janela é uma página local aberta no Edge (modo aplicativo);
# este script é o "motor": baixa com o yt-dlp e, se preciso, deixa o MP4 compatível com o Premiere (ffmpeg).
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
$env:PYTHONIOENCODING = 'utf-8'
$ErrorActionPreference = 'Continue'
# programas instalados agora há pouco (yt-dlp, ffmpeg) entram no PATH do Windows, mas não nesta sessão: relê o PATH
try { $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User') } catch {}

# ---------- marca (nome, cores e logo) ----------
$marca = @{ id = 'birutia'; nome = 'Baixador de Vídeos'; logo = 'logo-escura.png'; icone = 'icone.ico'; corPrincipal = @(98, 54, 199); corDestaque = @(255, 127, 0); botaoOutro = $true }
$arqMarca = Join-Path $PSScriptRoot 'marca.json'
if (Test-Path $arqMarca) {
  try {
    $m = Get-Content $arqMarca -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($k in 'id', 'nome', 'logo', 'icone', 'corPrincipal', 'corDestaque', 'transcricao', 'tema', 'botaoOutro') { if ($null -ne $m.$k) { $marca[$k] = $m.$k } }
  } catch {}
}

# ---------- configuração lembrada entre as aberturas ----------
$cfgDir = Join-Path $env:APPDATA ('Baixador-' + $marca.id)
$cfgArq = Join-Path $cfgDir 'config.json'
$cfg = [pscustomobject]@{ pasta = (Join-Path $env:USERPROFILE 'Downloads'); formato = 'mp4'; fechar = $false; abrir = $true; premiere = $true }
if (Test-Path $cfgArq) {
  try {
    $lido = Get-Content $cfgArq -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($k in 'pasta', 'formato', 'fechar', 'abrir', 'premiere') { if ($null -ne $lido.$k) { $cfg.$k = $lido.$k } }
  } catch {}
}
if (-not (Test-Path $cfg.pasta)) { $cfg.pasta = Join-Path $env:USERPROFILE 'Downloads' }
function Salvar-Config { try { New-Item -ItemType Directory -Force $cfgDir | Out-Null; $cfg | ConvertTo-Json | Set-Content $cfgArq -Encoding UTF8 } catch {} }

# ---------- estado do download (a página consulta isto) ----------
$saida = Join-Path $env:TEMP "baixador-saida-$PID.txt"
$erro = Join-Path $env:TEMP "baixador-erro-$PID.txt"
$arqProbe = Join-Path $env:TEMP "baixador-probe-$PID.json"
$arqProg = Join-Path $env:TEMP "baixador-prog-$PID.txt"
$S = @{ fase = 'espera'; pct = 0; texto = 'Aguardando o link.'; vel = ''; nota = ''; arquivo = ''; fechar = $false }
$script:proc = $null; $script:cancelado = $false; $script:existe = $false; $script:origem = 'outro'; $script:duracao = 0.0
$script:novo = ''; $script:sair = $false; $script:pingou = $false; $script:ultimoPing = Get-Date

function Erro-Amigavel($texto) {
  if ($texto -match 'Private video|Sign in|login required|rate-limit|Requested content is not available') { return 'O vídeo é privado ou exige login. Só é possível baixar vídeos públicos.' }
  if ($texto -match 'Unsupported URL') { return 'Esse endereço não é de um vídeo. Confira o link.' }
  if ($texto -match 'Unexpected response|impersonat|extractor') { return 'O site respondeu de um jeito inesperado. Rode de novo o instalador (ele atualiza o programa de download) e tente de novo.' }
  if ($texto -match 'HTTP Error 403|HTTP Error 429') { return 'O site bloqueou o download agora. Tente de novo em alguns minutos.' }
  if ($texto -match 'Video unavailable|unavailable') { return 'O vídeo não está disponível.' }
  if ($texto -match 'ffmpeg') { return 'Falta o ffmpeg. Rode de novo o instalador.' }
  if ($texto -match 'Unable to download webpage|getaddrinfo|Temporary failure|timed out') { return 'Não foi possível acessar o site. Confira a internet.' }
  return $texto
}
function Nome-Origem { switch ($script:origem) { 'youtube' { 'do YouTube' } 'instagram' { 'do Instagram' } default { 'do site' } } }
# Alguns antivírus e redes "abrem" o HTTPS com um certificado próprio, que só o Windows conhece. O curl do yt-dlp
# (usado no Instagram e no TikTok) então falha com "local issuer certificate". Nesse caso, uma vez, usamos a lista de
# certificados de confiança do próprio Windows (sem desligar nenhuma verificação).
$script:tentouCert = $false
function Preparar-Certificados {
  try {
    $dir = Join-Path $env:LOCALAPPDATA 'Baixador'; New-Item -ItemType Directory -Force $dir | Out-Null
    $pem = Join-Path $dir 'cacerts.pem'
    if (-not (Test-Path $pem) -or ((Get-Date) - (Get-Item $pem).LastWriteTime).TotalDays -gt 7) {
      $sb = New-Object Text.StringBuilder
      foreach ($loc in 'Cert:\LocalMachine\Root', 'Cert:\CurrentUser\Root', 'Cert:\LocalMachine\CA') {
        foreach ($c in (Get-ChildItem $loc -ErrorAction SilentlyContinue)) {
          [void]$sb.AppendLine('-----BEGIN CERTIFICATE-----'); [void]$sb.AppendLine([Convert]::ToBase64String($c.RawData, 'InsertLineBreaks')); [void]$sb.AppendLine('-----END CERTIFICATE-----')
        }
      }
      [IO.File]::WriteAllText($pem, $sb.ToString(), [Text.Encoding]::ASCII)
    }
    $env:CURL_CA_BUNDLE = $pem; $env:SSL_CERT_FILE = $pem
    return $true
  } catch { return $false }
}
function Fracao($s) { if ($s -match '^(\d+)/(\d+)$' -and [double]$Matches[2] -ne 0) { return [double]$Matches[1] / [double]$Matches[2] } return 0.0 }

function Fim-Ok($nota) {
  $nome = if ($S.arquivo) { Split-Path $S.arquivo -Leaf } else { '' }
  $S.fase = 'pronto'; $S.pct = 100; $S.vel = ''; $S.nota = $nota
  $S.texto = $(if ($script:existe) { "Esse vídeo já estava na pasta.`n$nome" } elseif ($nome) { "Pronto! Salvo como:`n$nome" } else { 'Pronto! O arquivo está na pasta escolhida.' })
  $S.fechar = [bool]$cfg.fechar
  if ($cfg.abrir) {
    if ($S.arquivo -and (Test-Path -LiteralPath $S.arquivo)) { Start-Process explorer.exe "/select,`"$($S.arquivo)`"" } else { Start-Process explorer.exe "`"$($cfg.pasta)`"" }
  }
}
function Fim-Erro($msg) { $S.fase = 'erro'; $S.pct = 0; $S.vel = ''; $S.nota = ''; $S.texto = 'Não foi possível baixar. ' + $msg }
function Parar-Processo { if ($script:proc -and -not $script:proc.HasExited) { try { & taskkill /PID $script:proc.Id /T /F | Out-Null } catch {} } }

# ---------- etapa 1: baixar (yt-dlp) ----------
function Iniciar-Download($link, $formato) {
  if ($formato -eq 'txt') { Iniciar-Texto $link; return }
  Remove-Item $saida, $erro -ErrorAction SilentlyContinue
  $script:cancelado = $false; $script:existe = $false
  $S.fase = 'baixando'; $S.pct = 0; $S.vel = ''; $S.nota = ''; $S.arquivo = ''; $S.fechar = $false
  $S.texto = 'Iniciando...'
  $p = $cfg.pasta; if ($p.EndsWith('\')) { $p += '\' }
  $a = @('--no-playlist', '--windows-filenames', '--trim-filenames', '150', '--newline', '--no-mtime', '--no-quiet',
         '--print', 'after_move:filepath', '-P', "`"$p`"", '-o', '"%(title)s.%(ext)s"')
  if ($formato -eq 'mp3') { $a += @('-x', '--audio-format', 'mp3', '--audio-quality', '0') }
  else { $a += @('-S', 'res,ext:mp4:m4a', '--merge-output-format', 'mp4') }
  $a += "`"$link`""
  try {
    $script:proc = Start-Process yt-dlp -ArgumentList $a -WindowStyle Hidden -PassThru -RedirectStandardOutput $saida -RedirectStandardError $erro
    $null = $script:proc.Handle # sem isso o PowerShell 5.1 devolve ExitCode vazio
  } catch { Fim-Erro 'Não foi possível iniciar o download. Rode de novo o instalador.' }
}
function Tick-Baixando {
  $linhas = @()
  try { $linhas = @(Get-Content $saida -Encoding UTF8 -ErrorAction Stop) } catch {}
  $partes = 1; $idx = 0; $pct = 0.0; $vel = ''; $eta = ''; $final = $false; $existe = $false
  foreach ($l in $linhas) {
    if ($l -match 'Downloading \d+ format\(s\): (\S+)') { $partes = ($Matches[1] -split '\+').Count }
    if ($l -match '^\[download\] Destination:') { $idx++; $pct = 0.0 }
    if ($l -match '^\[download\]\s+(\d+(\.\d+)?)%') {
      $pct = [double]$Matches[1]; $vel = ''; $eta = ''
      if ($l -match ' at\s+(\S+/s)') { $vel = $Matches[1] }
      if ($l -match 'ETA\s+(\S+)') { $eta = $Matches[1] }
    }
    if ($l -match '^\[(Merger|ExtractAudio|VideoConvertor|Fixup\w*|MoveFiles)\]') { $final = $true }
    if ($l -match 'has already been downloaded') { $existe = $true }
  }
  $total = 0.0
  if ($idx -ge 1) { $total = (([Math]::Min($idx, $partes) - 1) + ($pct / 100.0)) / $partes * 100.0 }
  if ($final) { $total = 99.0 }
  $v = [Math]::Max(0, [Math]::Min(100, [int][Math]::Floor($total)))
  if (-not $script:proc.HasExited) {
    $S.pct = $v; $S.vel = $vel
    if ($final) { $S.texto = 'Finalizando o arquivo...' }
    else { $S.texto = $(if ($script:formatoAtual -eq 'txt') { 'Baixando o áudio' } else { "Baixando $(Nome-Origem)" }) + $(if ($eta) { "  ·  faltam $eta" } else { '' }) }
    return
  }
  foreach ($l in $linhas) { $t = $l.Trim(); if ($t -and ($t -notmatch '^\[') -and ($t -match '^[A-Za-z]:\\') -and (Test-Path -LiteralPath $t)) { $S.arquivo = $t } }
  $script:existe = $existe
  if ($script:cancelado) { $S.fase = 'cancelado'; $S.pct = 0; $S.vel = ''; $S.texto = 'Download cancelado.'; return }
  if ($script:proc.ExitCode -ne 0) {
    $msg = ''
    try {
      $todas = @(Get-Content $erro -Encoding UTF8 -ErrorAction Stop) + @(Get-Content $saida -Encoding UTF8 -ErrorAction SilentlyContinue)
      $erros = @($todas | Where-Object { $_ -match '^ERROR' })
      $msg = $(if ($erros.Count) { ($erros | Select-Object -Last 1) -replace '^ERROR:\s*(\[[^\]]+\]\s*)?(\S+:\s*)?', '' } else { ($todas | Where-Object { $_.Trim() } | Select-Object -Last 2) -join ' ' })
    } catch {}
    if ($msg -match 'local issuer certificate' -and -not $script:tentouCert -and $script:linkAtual) {
      $script:tentouCert = $true
      if (Preparar-Certificados) { $S.texto = 'Ajustando a conexão segura e tentando de novo...'; Iniciar-Download $script:linkAtual $script:formatoAtual; return }
    }
    $am = Erro-Amigavel $msg
    if ($am.Length -gt 140) { $am = $am.Substring(0, 140) + '...' }
    Fim-Erro $am; return
  }
  $S.vel = ''
  if ($script:formatoAtual -eq 'txt') { Iniciar-Voz; return }
  if ($script:formatoAtual -eq 'mp4' -and $script:premiereAtual -and $script:origem -ne 'youtube' -and $S.arquivo -and (Test-Path -LiteralPath $S.arquivo)) { Iniciar-Conferir }
  else { Fim-Ok '' }
}

# ---------- etapa 2: conferir se o vídeo serve para o Premiere (ffprobe) ----------
function Iniciar-Conferir {
  $S.fase = 'conferindo'; $S.pct = 0; $S.texto = 'Conferindo se o vídeo abre no Premiere...'
  Remove-Item $arqProbe, ($arqProbe + '.err') -ErrorAction SilentlyContinue
  $a = @('-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=codec_name,pix_fmt,r_frame_rate,avg_frame_rate:format=duration', '-of', 'json', "`"$($S.arquivo)`"")
  try { $script:proc = Start-Process ffprobe -ArgumentList $a -WindowStyle Hidden -PassThru -RedirectStandardOutput $arqProbe -RedirectStandardError ($arqProbe + '.err'); $null = $script:proc.Handle }
  catch { Fim-Ok 'Não consegui conferir o formato; o arquivo original foi mantido.' }
}
function Tick-Conferir {
  if (-not $script:proc.HasExited) { return }
  if ($script:cancelado) { Fim-Ok ''; return }
  if ($script:proc.ExitCode -ne 0) { Fim-Ok 'Não consegui conferir o formato; o arquivo original foi mantido.'; return }
  try {
    $j = Get-Content $arqProbe -Raw -Encoding UTF8 | ConvertFrom-Json
    $v = @($j.streams)[0]
    if (-not $v) { Fim-Ok ''; return }
    $script:duracao = 0.0; try { $script:duracao = [double]$j.format.duration } catch {}
    $r = Fracao $v.r_frame_rate; $m = Fracao $v.avg_frame_rate
    $variavel = ($m -gt 0) -and ([Math]::Abs($r - $m) / $m -gt 0.01)
    if (-not $ForcarAjuste -and $v.codec_name -eq 'h264' -and $v.pix_fmt -eq 'yuv420p' -and -not $variavel) { Fim-Ok 'Já estava compatível com o Premiere.'; return }
    Iniciar-Ajuste $m
  } catch { Fim-Ok 'Não consegui conferir o formato; o arquivo original foi mantido.' }
}

# ---------- etapa 3: ajustar (ffmpeg): H.264, 8 bits, quadros constantes, áudio AAC ----------
function Iniciar-Ajuste($m) {
  $fps = '30'; $melhor = 1e9
  if ($m -le 0) { $m = 30 }
  foreach ($o in @(@(23.976, '24000/1001'), @(24, '24'), @(25, '25'), @(29.97, '30000/1001'), @(30, '30'), @(50, '50'), @(59.94, '60000/1001'), @(60, '60'))) {
    $d = [Math]::Abs($m - $o[0]); if ($d -lt $melhor) { $melhor = $d; $fps = $o[1] }
  }
  $script:novo = [IO.Path]::ChangeExtension($S.arquivo, '.premiere.mp4')
  Remove-Item -LiteralPath $script:novo, $arqProg -ErrorAction SilentlyContinue
  $S.fase = 'ajustando'; $S.pct = 0; $S.texto = 'Ajustando para o Premiere...'
  $a = @('-y', '-i', "`"$($S.arquivo)`"", '-map', '0:v:0', '-map', '0:a?', '-vf', '"scale=trunc(iw/2)*2:trunc(ih/2)*2"',
         '-c:v', 'libx264', '-preset', 'medium', '-crf', '16', '-pix_fmt', 'yuv420p', '-r', $fps, '-fps_mode', 'cfr',
         '-c:a', 'aac', '-b:a', '192k', '-ar', '48000', '-movflags', '+faststart', '-progress', "`"$arqProg`"", '-nostats', "`"$($script:novo)`"")
  try { $script:proc = Start-Process ffmpeg -ArgumentList $a -WindowStyle Hidden -PassThru -RedirectStandardOutput ($arqProbe + '.out') -RedirectStandardError ($arqProbe + '.err'); $null = $script:proc.Handle }
  catch { Fim-Ok 'Não consegui ajustar o vídeo; o arquivo original foi mantido.' }
}
function Tick-Ajuste {
  if (-not $script:proc.HasExited) {
    try {
      $l = @(Get-Content $arqProg -Tail 30 -ErrorAction Stop | Where-Object { $_ -match '^out_time_(us|ms)=\d+' }) | Select-Object -Last 1
      if ($l -and $script:duracao -gt 0) {
        $us = [double](($l -split '=')[1]); $p = [Math]::Min(99, [int]($us / 1e6 / $script:duracao * 100)); if ($p -gt $S.pct) { $S.pct = $p }
      }
    } catch {}
    return
  }
  if ($script:cancelado) { Remove-Item -LiteralPath $script:novo -ErrorAction SilentlyContinue; Fim-Ok 'Ajuste cancelado; o arquivo original foi mantido.'; return }
  if ($script:proc.ExitCode -ne 0 -or -not (Test-Path -LiteralPath $script:novo) -or (Get-Item -LiteralPath $script:novo).Length -lt 1024) {
    Remove-Item -LiteralPath $script:novo -ErrorAction SilentlyContinue
    Fim-Ok 'Não consegui ajustar o vídeo; o arquivo original foi mantido.'; return
  }
  try { Move-Item -LiteralPath $script:novo -Destination $S.arquivo -Force; Fim-Ok 'Ajustado para o Premiere (H.264, quadros constantes).' }
  catch { Fim-Ok 'Não consegui trocar o arquivo; o ajustado ficou ao lado, com final .premiere.mp4.' }
}

# ---------- só transcrição: legendas do YouTube ou reconhecimento de voz (Whisper, no próprio computador) ----------
$script:tmp = Join-Path $env:TEMP "baixador-txt-$PID"
$script:py = $null; $script:linkAtual = ''; $script:tentativa = 1; $script:audio = ''; $script:txt = ''
function Limpar-Tmp { Remove-Item -LiteralPath $script:tmp -Recurse -Force -ErrorAction SilentlyContinue }
function Iniciar-Texto($link) {
  Remove-Item $saida, $erro -ErrorAction SilentlyContinue
  $script:cancelado = $false; $script:existe = $false; $script:linkAtual = $link
  $S.pct = 0; $S.vel = ''; $S.nota = ''; $S.arquivo = ''; $S.fechar = $false
  Limpar-Tmp; New-Item -ItemType Directory -Force $script:tmp | Out-Null
  if ($script:origem -eq 'youtube') { Iniciar-Legendas } else { Iniciar-Audio }
}
function Lancar-Legendas($flag, $langs) {
  Get-ChildItem -LiteralPath $script:tmp -Filter '*.srt' -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
  $a = @('--no-playlist', '--windows-filenames', '--trim-filenames', '150', '--no-mtime', '--skip-download', $flag, '--sub-langs', $langs,
         '--convert-subs', 'srt', '-P', "`"$($script:tmp)`"", '-o', '"%(title)s.%(ext)s"', "`"$($script:linkAtual)`"")
  try { $script:proc = Start-Process yt-dlp -ArgumentList $a -WindowStyle Hidden -PassThru -RedirectStandardOutput $saida -RedirectStandardError $erro; $null = $script:proc.Handle }
  catch { Limpar-Tmp; Fim-Erro 'Não foi possível iniciar o download. Rode de novo o instalador.' }
}
function Iniciar-Legendas {
  $S.fase = 'legendas'; $S.texto = 'Procurando as legendas do vídeo...'
  $script:tentativa = 1
  Lancar-Legendas '--write-subs' '"pt,pt-BR,pt-PT,en"'   # 1) legendas feitas por pessoas
}
function Tick-Legendas {
  if (-not $script:proc.HasExited) { return }
  if ($script:cancelado) { Limpar-Tmp; $S.fase = 'cancelado'; $S.pct = 0; $S.texto = 'Cancelado.'; return }
  $srt = @(Get-ChildItem -LiteralPath $script:tmp -Filter '*.srt' -ErrorAction SilentlyContinue | Sort-Object { $_.Name -match '-orig' })
  if ($srt.Count -gt 0) { Concluir-Legenda $srt[0]; return }
  if ($script:tentativa -eq 1) { $script:tentativa = 2; $S.texto = 'Procurando as legendas automáticas...'; Lancar-Legendas '--write-auto-subs' '".*-orig"'; return }  # 2) legendas automáticas, no idioma original
  Iniciar-Audio   # sem legenda nenhuma: ouvir o áudio
}
function Concluir-Legenda($srt) {
  $nome = [IO.Path]::GetFileNameWithoutExtension($srt.Name) -replace '\.[A-Za-z]{2,3}(-[A-Za-z0-9]+)*$', ''
  $linhas = @(Get-Content -LiteralPath $srt.FullName -Encoding UTF8)
  $ult = ''; $partes = New-Object Collections.Generic.List[string]
  foreach ($l in $linhas) {
    $x = ($l -replace '<[^>]+>', '' -replace '&nbsp;', ' ' -replace '&amp;', '&' -replace '&gt;', '>' -replace '&lt;', '<').Trim()
    if (-not $x -or $x -match '^\d+$' -or $x -match '^\d{2}:\d{2}:\d{2}[,.]\d{3}\s*-->') { continue }
    if ($x -eq $ult -or ($ult -and $ult.EndsWith($x))) { continue }   # legenda automática repete linhas
    $partes.Add($x); $ult = $x
  }
  $pal = ($partes -join ' ') -split '\s+'
  $par = New-Object Collections.Generic.List[string]; $cur = New-Object Collections.Generic.List[string]
  foreach ($w in $pal) {
    $cur.Add($w)
    if (($cur.Count -ge 40 -and $w -match '[\.\?\!…]$') -or $cur.Count -ge 80) { $par.Add(($cur -join ' ')); $cur.Clear() }
  }
  if ($cur.Count) { $par.Add(($cur -join ' ')) }
  $txt = Join-Path $cfg.pasta ($nome + '.txt')
  [IO.File]::WriteAllText($txt, (($par -join "`r`n`r`n") + "`r`n"), (New-Object Text.UTF8Encoding($true)))
  $S.arquivo = $txt; Limpar-Tmp
  Fim-Ok 'Texto tirado das legendas do vídeo.'
}
function Iniciar-Audio {
  $S.fase = 'baixando'; $S.pct = 0; $S.texto = 'Baixando o áudio...'
  Remove-Item $saida, $erro -ErrorAction SilentlyContinue
  $a = @('--no-playlist', '--windows-filenames', '--trim-filenames', '150', '--newline', '--no-mtime', '--no-quiet', '--print', 'after_move:filepath',
         '-P', "`"$($script:tmp)`"", '-o', '"%(title)s.%(ext)s"', '-x', '--audio-format', 'wav', '--postprocessor-args', '"ExtractAudio:-ar 16000 -ac 1"', "`"$($script:linkAtual)`"")
  try { $script:proc = Start-Process yt-dlp -ArgumentList $a -WindowStyle Hidden -PassThru -RedirectStandardOutput $saida -RedirectStandardError $erro; $null = $script:proc.Handle }
  catch { Limpar-Tmp; Fim-Erro 'Não foi possível iniciar o download. Rode de novo o instalador.' }
}
function Achar-Python {
  if ($script:py) { return $script:py }
  $cands = @()
  foreach ($n in 'py', 'python') {
    $c = Get-Command $n -ErrorAction SilentlyContinue | Where-Object { $_.Source -notmatch 'WindowsApps' } | Select-Object -First 1
    if ($c) { $cands += [pscustomobject]@{ exe = $c.Source; pre = $(if ($n -eq 'py') { @('-3') } else { @() }) } }
  }
  foreach ($d in (Get-ChildItem (Join-Path $env:LOCALAPPDATA 'Programs\Python') -Directory -Filter 'Python3*' -ErrorAction SilentlyContinue | Sort-Object Name -Descending)) {
    $e = Join-Path $d.FullName 'python.exe'; if (Test-Path $e) { $cands += [pscustomobject]@{ exe = $e; pre = @() } }
  }
  foreach ($c in $cands) {
    $a = @($c.pre) + @('-c', '"import faster_whisper"')
    try { $p = Start-Process $c.exe -ArgumentList $a -WindowStyle Hidden -PassThru -Wait; $null = $p.Handle; if ($p.ExitCode -eq 0) { $script:py = @{ exe = $c.exe; pre = @($c.pre) }; return $script:py } } catch {}
  }
  return $null
}
function Iniciar-Voz {
  $script:audio = $S.arquivo; $S.arquivo = ''
  if (-not $script:audio -or -not (Test-Path -LiteralPath $script:audio)) { Limpar-Tmp; Fim-Erro 'Não encontrei o áudio baixado.'; return }
  $S.fase = 'transcrevendo'; $S.pct = 0; $S.texto = 'Preparando a transcrição...'
  $py = Achar-Python
  if (-not $py) { Limpar-Tmp; Fim-Erro 'Falta o recurso de transcrição por voz. Rode de novo o instalador.'; return }
  $script:txt = Join-Path $cfg.pasta ([IO.Path]::GetFileNameWithoutExtension($script:audio) + '.txt')
  Remove-Item $arqProg, ($arqProg + '.err') -ErrorAction SilentlyContinue
  $S.texto = 'Transcrevendo a fala (na primeira vez baixa o modelo de voz, pode demorar)...'
  $a = @($py.pre) + @('-u', "`"$PSScriptRoot\transcrever.py`"", "`"$($script:audio)`"", "`"$($script:txt)`"")
  try { $script:proc = Start-Process $py.exe -ArgumentList $a -WindowStyle Hidden -PassThru -RedirectStandardOutput $arqProg -RedirectStandardError ($arqProg + '.err'); $null = $script:proc.Handle }
  catch { Limpar-Tmp; Fim-Erro 'Não foi possível iniciar a transcrição.' }
}
function Tick-Voz {
  if (-not $script:proc.HasExited) {
    try {
      $l = @(Get-Content $arqProg -Tail 20 -Encoding UTF8 -ErrorAction Stop | Where-Object { $_ -match '^PROGRESSO \d+' }) | Select-Object -Last 1
      if ($l) { $p = [int](($l -split ' ')[1]); if ($p -gt $S.pct) { $S.pct = $p; $S.texto = 'Transcrevendo a fala...' } }
    } catch {}
    return
  }
  if ($script:cancelado) { Remove-Item -LiteralPath $script:txt -ErrorAction SilentlyContinue; Limpar-Tmp; $S.fase = 'cancelado'; $S.pct = 0; $S.texto = 'Cancelado.'; return }
  if ($script:proc.ExitCode -eq 0 -and (Test-Path -LiteralPath $script:txt)) {
    $S.arquivo = $script:txt; Limpar-Tmp
    Fim-Ok 'Texto gerado por reconhecimento de voz (Whisper). Confira nomes e termos técnicos.'; return
  }
  $msg = ''
  try { $msg = (@(Get-Content $arqProg -Encoding UTF8 -ErrorAction Stop) + @(Get-Content ($arqProg + '.err') -Encoding UTF8 -ErrorAction SilentlyContinue) | Where-Object { $_ -match '^ERRO' } | Select-Object -Last 1) -replace '^ERRO\s*', '' } catch {}
  if ($msg -match 'No module named') { $msg = 'Falta o recurso de transcrição por voz. Rode de novo o instalador.' }
  if ($msg.Length -gt 140) { $msg = $msg.Substring(0, 140) + '...' }
  Limpar-Tmp; Fim-Erro $msg
}

function Tick-Seguro {
  try { Tick }
  catch {
    try { Add-Content -LiteralPath (Join-Path $env:TEMP 'baixador-motor-erro.log') -Value ("$(Get-Date -Format s) $($_.Exception.Message)") } catch {}
    if ($S.fase -in 'baixando', 'conferindo', 'ajustando', 'legendas', 'transcrevendo') { Parar-Processo; Limpar-Tmp; Fim-Erro 'Houve uma falha inesperada. Tente de novo.' }
  }
}
function Tick {
  switch ($S.fase) {
    'baixando' { Tick-Baixando }
    'conferindo' { Tick-Conferir }
    'ajustando' { Tick-Ajuste }
    'legendas' { Tick-Legendas }
    'transcrevendo' { Tick-Voz }
  }
}

# ---------- servidor local (só este computador, com senha aleatória) ----------
$token = [guid]::NewGuid().ToString('N')
$ln = $null; $porta = 0
foreach ($try in 1..40) {
  $porta = Get-Random -Minimum 49152 -Maximum 65000
  $ln = New-Object Net.HttpListener
  $ln.Prefixes.Add("http://127.0.0.1:$porta/")
  try { $ln.Start(); break } catch { $ln = $null }
}
if (-not $ln) { [Windows.Forms.MessageBox]::Show('Não consegui abrir o programa (porta ocupada). Tente de novo.', 'Baixador'); exit 1 }

function Enviar($rs, $codigo, $tipo, [byte[]]$bytes) {
  $rs.StatusCode = $codigo; $rs.ContentType = $tipo
  $rs.Headers.Add('Cache-Control', 'no-store')
  $rs.ContentLength64 = $bytes.Length
  $rs.OutputStream.Write($bytes, 0, $bytes.Length)
  $rs.OutputStream.Close()
}
function Json($rs, $obj) { Enviar $rs 200 'application/json; charset=utf-8' ([Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress -Depth 5))) }
function Corpo($rq) { $r = New-Object IO.StreamReader($rq.InputStream, [Text.Encoding]::UTF8); $t = $r.ReadToEnd(); if ($t) { $t | ConvertFrom-Json } else { [pscustomobject]@{} } }
function Clip { try { [Windows.Forms.Clipboard]::GetText() } catch { '' } }

function Atender($ctx) {
  $rq = $ctx.Request; $rs = $ctx.Response
  try {
    $tok = $rq.Headers['X-Token']; if (-not $tok) { $tok = $rq.QueryString['t'] }
    if ($tok -ne $token -or $rq.Headers['Host'] -ne "127.0.0.1:$porta") { Enviar $rs 403 'text/plain' ([Text.Encoding]::UTF8.GetBytes('negado')); return }
    $c = $rq.Url.AbsolutePath
    if ($c -eq '/') { Enviar $rs 200 'text/html; charset=utf-8' ([IO.File]::ReadAllBytes((Join-Path $PSScriptRoot 'index.html'))); return }
    if ($c -eq '/logo') { Enviar $rs 200 'image/png' ([IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $marca.logo))); return }
    if ($c -eq '/icone') { Enviar $rs 200 'image/x-icon' ([IO.File]::ReadAllBytes((Join-Path $PSScriptRoot $marca.icone))); return }
    switch ($c) {
      '/api/ping' { $script:pingou = $true; $script:ultimoPing = Get-Date; Json $rs @{ ok = $true } }
      '/api/estado' { Json $rs @{ marca = $marca; cfg = $cfg; clip = (Clip) } }
      '/api/clip' { Json $rs @{ texto = (Clip) } }
      '/api/status' { Json $rs $S }
      '/api/config' {
        $j = Corpo $rq
        if ($j.formato -in 'mp4', 'mp3', 'txt') { $cfg.formato = $j.formato }
        foreach ($k in 'premiere', 'abrir', 'fechar') { if ($null -ne $j.$k) { $cfg.$k = [bool]$j.$k } }
        Salvar-Config; Json $rs @{ ok = $true }
      }
      '/api/pasta' {
        $dono = New-Object Windows.Forms.Form -Property @{ TopMost = $true; ShowInTaskbar = $false; Opacity = 0; StartPosition = 'CenterScreen'; Width = 1; Height = 1 }
        $dono.Show()
        $d = New-Object Windows.Forms.FolderBrowserDialog
        $d.Description = 'Escolha a pasta onde os vídeos serão salvos'; $d.SelectedPath = $cfg.pasta; $d.ShowNewFolderButton = $true
        if ($d.ShowDialog($dono) -eq 'OK') { $cfg.pasta = $d.SelectedPath; Salvar-Config }
        $dono.Close()
        Json $rs @{ pasta = $cfg.pasta }
      }
      '/api/abrir-pasta' { Start-Process explorer.exe "`"$($cfg.pasta)`""; Json $rs @{ ok = $true } }
      '/api/cancelar' {
        if ($S.fase -in 'baixando', 'conferindo', 'ajustando', 'legendas', 'transcrevendo') { $script:cancelado = $true; Parar-Processo }
        Json $rs @{ ok = $true }
      }
      '/api/sair' { $script:sair = $true; Json $rs @{ ok = $true } }
      '/api/baixar' {
        $j = Corpo $rq
        $link = "$($j.link)".Trim()
        if ($link -notmatch '^https?://[^\s"]+$') { Json $rs @{ ok = $false; msg = 'Cole um link válido (começa com https://).' }; return }
        if (-not (Test-Path $cfg.pasta)) { Json $rs @{ ok = $false; msg = 'A pasta escolhida não existe mais. Clique em Escolher.' }; return }
        if ($S.fase -in 'baixando', 'conferindo', 'ajustando', 'legendas', 'transcrevendo') { Json $rs @{ ok = $false; msg = 'Já há um download em andamento.' }; return }
        if ($j.formato -in 'mp4', 'mp3', 'txt') { $cfg.formato = $j.formato }
        foreach ($k in 'premiere', 'abrir', 'fechar') { if ($null -ne $j.$k) { $cfg.$k = [bool]$j.$k } }
        Salvar-Config
        $script:origem = $(if ($j.origem -in 'youtube', 'instagram', 'outro') { $j.origem } else { 'outro' })
        $script:formatoAtual = $cfg.formato; $script:premiereAtual = [bool]$cfg.premiere
        $script:linkAtual = $link; $script:tentouCert = $false
        Iniciar-Download $link $cfg.formato
        Json $rs @{ ok = $true }
      }
      default { Enviar $rs 404 'text/plain' ([Text.Encoding]::UTF8.GetBytes('?')) }
    }
  } catch { try { $rs.Abort() } catch {} }
}

# ---------- abre a janela ----------
function Achar-Navegador {
  $pf86 = ${env:ProgramFiles(x86)}
  @("$pf86\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
    "$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "$pf86\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") |
    Where-Object { Test-Path -LiteralPath $_ } | Select-Object -First 1
}
$url = "http://127.0.0.1:$porta/?t=$token"
if ($SemJanela) { Write-Host "URL: $url"; Write-Host "TOKEN: $token"; Write-Host "PORTA: $porta" }
else {
  $nav = Achar-Navegador
  if (-not $nav) { [Windows.Forms.MessageBox]::Show('Este programa precisa do Microsoft Edge (já vem com o Windows) ou do Google Chrome.', 'Baixador'); exit 1 }
  $area = [Windows.Forms.Screen]::PrimaryScreen.WorkingArea
  $h = [Math]::Min(900, $area.Height - 20); $w = 600
  $x = [int]($area.X + ($area.Width - $w) / 2); $y = [int]($area.Y + ($area.Height - $h) / 2)
  $perfil = Join-Path $cfgDir 'janela'
  New-Item -ItemType Directory -Force $perfil | Out-Null
  Start-Process $nav -ArgumentList @("--app=$url", "--window-size=$w,$h", "--window-position=$x,$y", "--user-data-dir=`"$perfil`"", '--no-first-run', '--no-default-browser-check', '--disable-extensions', '--disable-background-mode')
}

# ---------- laço principal: atende a página e acompanha o download ----------
function Janela-Aberta {
  try { return [bool](Get-CimInstance Win32_Process -Filter "Name='msedge.exe' OR Name='chrome.exe'" -ErrorAction Stop | Where-Object { $_.CommandLine -like "*--app=http://127.0.0.1:$porta/*" } | Select-Object -First 1) }
  catch { return $true }
}
$script:viuJanela = $false; $script:semTela = 0; $ultimaConf = Get-Date
$inicio = Get-Date
try {
  while ($ln.IsListening -and -not $script:sair) {
    $t = $ln.GetContextAsync()
    while (-not $t.AsyncWaitHandle.WaitOne(250)) {
      Tick-Seguro
      if ($script:sair) { break }
      if (-not $SemJanela) {
        $rodando = $S.fase -in 'baixando', 'conferindo', 'ajustando', 'legendas', 'transcrevendo'
        if (((Get-Date) - $ultimaConf).TotalSeconds -ge 5) {
          $ultimaConf = Get-Date
          if (Janela-Aberta) { $script:viuJanela = $true; $script:semTela = 0 } elseif ($script:viuJanela) { $script:semTela++ }
        }
        # a janela foi fechada (uns 15 s sem ela) e não há download em andamento: encerra
        if ($script:semTela -ge 3 -and -not $rodando) { $script:sair = $true; break }
        # a janela nunca apareceu
        if (-not $script:viuJanela -and ((Get-Date) - $inicio).TotalSeconds -gt 90) { $script:sair = $true; break }
        # reserva: sem sinal nenhum da página por 30 minutos e sem download
        if ($script:pingou -and -not $rodando -and ((Get-Date) - $script:ultimoPing).TotalMinutes -gt 30) { $script:sair = $true; break }
      }
    }
    if ($t.IsCompleted -and -not $t.IsFaulted) { Atender $t.Result; Tick-Seguro }
  }
} finally {
  Parar-Processo
  Limpar-Tmp
  try { $ln.Stop(); $ln.Close() } catch {}
  Remove-Item $saida, $erro, $arqProbe, ($arqProbe + '.err'), ($arqProbe + '.out'), $arqProg -ErrorAction SilentlyContinue
}
