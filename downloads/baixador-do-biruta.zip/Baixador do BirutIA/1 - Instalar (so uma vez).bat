@echo off
chcp 65001 >nul
title Instalando o Baixador de Videos
echo.
echo Instalando as ferramentas para baixar videos. Aguarde...
echo (se aparecer uma pergunta do Windows, clique em Sim)
echo.
winget install -e --id yt-dlp.yt-dlp --accept-source-agreements --accept-package-agreements
winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
echo.
set "PASTA=%~dp0"
echo Procurando versoes antigas do Baixador (a copia anterior sera apagada)...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Limpar-instalacoes-antigas.ps1"
echo.
echo Criando o atalho na Area de Trabalho...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Criar-atalho.ps1"
echo.
echo Pronto! Use o atalho do Baixador na Area de Trabalho.
echo (Nao mova nem apague esta pasta.)
pause
