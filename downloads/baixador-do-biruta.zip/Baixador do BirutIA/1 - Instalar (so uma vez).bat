@echo off
chcp 65001 >nul
title Instalando o Baixador do BirutIA
echo.
echo Instalando as ferramentas para baixar videos. Aguarde...
echo (se aparecer uma pergunta do Windows, clique em Sim)
echo.
winget install -e --id yt-dlp.yt-dlp --accept-source-agreements --accept-package-agreements
winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
echo.
echo.
echo Criando o atalho na Area de Trabalho...
set "PASTA=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=$env:PASTA; $s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Baixador do BirutIA.lnk'); $s.TargetPath=$env:windir+'\System32\WindowsPowerShell\v1.0\powershell.exe'; $s.Arguments='-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File '+[char]34+$p+'BaixadorVideos.ps1'+[char]34; $s.WorkingDirectory=$p; $s.IconLocation=$p+'icone.ico'; $s.Save()"
echo.
echo Pronto! Use o atalho "Baixador do BirutIA" na Area de Trabalho.
echo (Nao mova nem apague esta pasta.)
pause
