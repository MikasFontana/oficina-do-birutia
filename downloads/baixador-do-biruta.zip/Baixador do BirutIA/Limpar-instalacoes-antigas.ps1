﻿param([string]$Pasta = $env:PASTA, [string]$AreaDeTrabalho = '', [string[]]$ProcurarEm = @(), [string[]]$Fixados = @(), [switch]$SemPerguntar, [switch]$Isolado)
# Procura versões antigas do Baixador e arruma tudo, depois de perguntar:
#  - atalhos e pastas antigas são APAGADOS;
#  - atalhos FIXADOS na barra de tarefas ou no Iniciar são ATUALIZADOS para a versão nova (o ícone continua lá).
# Segurança: só apaga arquivos que pertencem ao Baixador. Nunca apaga a pasta atual,
# o yt-dlp, o ffmpeg nem os vídeos que você baixou.
$ErrorActionPreference = 'SilentlyContinue'
$atual = ([IO.Path]::GetFullPath($Pasta)).TrimEnd('\')

$desktops = @()
if ($AreaDeTrabalho) { $desktops += $AreaDeTrabalho }
else {
  $desktops += [Environment]::GetFolderPath('Desktop')
  $desktops += [Environment]::GetFolderPath('CommonDesktopDirectory')
}
$desktops = $desktops | Where-Object { $_ -and (Test-Path $_) } | Select-Object -Unique

if (-not $Isolado -and $Fixados.Count -eq 0) {
  $base = Join-Path $env:APPDATA 'Microsoft\Internet Explorer\Quick Launch\User Pinned'
  $Fixados = @((Join-Path $base 'TaskBar'), (Join-Path $base 'StartMenu'))
}

# arquivos que pertencem a qualquer versão do Baixador (é só isso que será apagado)
$conhecidos = @('BaixadorVideos.ps1', 'Abrir Baixador.bat', 'Abrir Baixador (ver erro).bat', '1 - Instalar (so uma vez).bat',
                'Limpar-instalacoes-antigas.ps1', 'Criar-atalho.ps1', 'marca.json', 'icone.ico', 'cabeca.png', 'foto.png', 'foto-bm.png',
                'logo.png', 'logo-escura.png', 'LEIA-ME.txt', 'Baixar Video.bat')

# nome e ícone do atalho novo (vêm do marca.json da pasta atual)
$atalhoNovo = 'Baixador do BirutIA.lnk'
$icone = 'icone.ico'
$arqMarca = Join-Path $atual 'marca.json'
if (Test-Path $arqMarca) {
  try {
    $mj = Get-Content $arqMarca -Raw -Encoding UTF8 | ConvertFrom-Json
    $nn = $(if ($mj.atalho) { $mj.atalho } else { $mj.nome })
    if ($nn) { $atalhoNovo = (($nn -replace '[\\/:*?"<>|]', '') + '.lnk') }
    if ($mj.icone) { $icone = $mj.icone }
  } catch {}
}

$shell = New-Object -ComObject WScript.Shell
$achados = New-Object System.Collections.ArrayList          # a apagar: @{ Caminho; Pasta }
$fixadosAchados = New-Object System.Collections.ArrayList   # a atualizar: @{ Caminho; Pasta }

function Eh-Pasta-Do-Baixador($dir) { (Test-Path -LiteralPath (Join-Path $dir 'BaixadorVideos.ps1')) -or (Test-Path -LiteralPath (Join-Path $dir 'Abrir Baixador.bat')) }
function Pasta-Do-Script($s) {
  if ($s.Arguments -match '-File\s+"?([^"]+BaixadorVideos\.ps1)') { return (Split-Path $Matches[1] -Parent) }
  if ($s.TargetPath -match '\.bat$') { return (Split-Path $s.TargetPath -Parent) }
  return ''
}

foreach ($d in $desktops) {
  foreach ($l in (Get-ChildItem -LiteralPath $d -Filter '*.lnk' -File)) {
    $s = $shell.CreateShortcut($l.FullName)
    if ("$($l.Name) $($s.TargetPath) $($s.Arguments)" -notmatch 'Baixador|BaixadorVideos|Baixar Video') { continue }
    $pa = Pasta-Do-Script $s
    $mesmaPasta = $pa -and (([IO.Path]::GetFullPath($pa)).TrimEnd('\') -ieq $atual)
    if ($l.Name -ieq $atalhoNovo -and $mesmaPasta) { continue }   # é o que vamos recriar
    [void]$achados.Add(@{ Caminho = $l.FullName; Pasta = $pa })
  }
  foreach ($b in (Get-ChildItem -LiteralPath $d -Filter 'Baixar Video*.bat' -File)) { [void]$achados.Add(@{ Caminho = $b.FullName; Pasta = '' }) }
}
foreach ($d in ($Fixados | Where-Object { $_ -and (Test-Path -LiteralPath $_) })) {
  foreach ($l in (Get-ChildItem -LiteralPath $d -Filter '*.lnk' -File)) {
    $s = $shell.CreateShortcut($l.FullName)
    if ("$($l.Name) $($s.TargetPath) $($s.Arguments)" -notmatch 'Baixador|BaixadorVideos|Baixar Video') { continue }
    [void]$fixadosAchados.Add(@{ Caminho = $l.FullName; Pasta = (Pasta-Do-Script $s) })
  }
}

# pastas antigas: as apontadas pelos atalhos e as encontradas em locais comuns
$pastas = @{}
foreach ($a in @($achados) + @($fixadosAchados)) { if ($a.Pasta -and (Test-Path -LiteralPath $a.Pasta)) { $pastas[([IO.Path]::GetFullPath($a.Pasta)).TrimEnd('\')] = $true } }
$locais = @($desktops) + $ProcurarEm
if (-not $Isolado) { $locais += @([Environment]::GetFolderPath('MyDocuments'), (Join-Path $env:USERPROFILE 'Downloads')) }
foreach ($loc in ($locais | Where-Object { $_ -and (Test-Path $_) })) {
  foreach ($sub in (Get-ChildItem -LiteralPath $loc -Directory | Where-Object { $_.Name -match 'Baixador' })) {
    if (Eh-Pasta-Do-Baixador $sub.FullName) { $pastas[([IO.Path]::GetFullPath($sub.FullName)).TrimEnd('\')] = $true }
  }
}
$pastas.Remove($atual) | Out-Null
$pastasAntigas = @($pastas.Keys | Where-Object { Eh-Pasta-Do-Baixador $_ })

if ($achados.Count -eq 0 -and $pastasAntigas.Count -eq 0 -and $fixadosAchados.Count -eq 0) { Write-Host 'Nenhuma versão antiga do Baixador encontrada.'; exit 0 }

Write-Host ''
Write-Host 'Encontrei versões antigas do Baixador neste computador:' -ForegroundColor Yellow
foreach ($a in $achados) { Write-Host "  - atalho a apagar: $($a.Caminho)" }
foreach ($p in $pastasAntigas) { Write-Host "  - pasta a apagar: $p" }
foreach ($f in $fixadosAchados) { Write-Host "  - atalho fixado (será ATUALIZADO, e não apagado): $($f.Caminho)" }
Write-Host ''
Write-Host 'Serão apagados apenas os arquivos do Baixador. Os vídeos que você baixou,'
Write-Host 'o yt-dlp e o ffmpeg NÃO serão mexidos.'
$resp = 'S'
if (-not $SemPerguntar) { $resp = Read-Host 'Apagar as versões antigas? [S/N] (Enter = S)' }
if ($resp -and $resp.Trim().ToUpper() -notin @('S', 'SIM', 'Y')) { Write-Host 'Mantidas. Nada foi alterado.'; exit 0 }

$apagados = 0
foreach ($a in $achados) { if (Test-Path -LiteralPath $a.Caminho) { Remove-Item -LiteralPath $a.Caminho -Force; $apagados++ } }
foreach ($p in $pastasAntigas) {
  foreach ($nome in $conhecidos) { $f = Join-Path $p $nome; if (Test-Path -LiteralPath $f) { Remove-Item -LiteralPath $f -Force; $apagados++ } }
  foreach ($f in (Get-ChildItem -LiteralPath $p -Filter 'logo*.png' -File)) { Remove-Item -LiteralPath $f.FullName -Force; $apagados++ }
  # a pasta só some se ficou vazia; se tiver outra coisa dentro, ela é preservada
  if (-not (Get-ChildItem -LiteralPath $p -Force)) { Remove-Item -LiteralPath $p -Force }
  elseif (Test-Path -LiteralPath $p) { Write-Host "  (a pasta $p tinha outros arquivos e foi mantida)" }
}

# atalhos fixados: apontam para a versão nova (o ícone da barra de tarefas continua no lugar)
$atualizados = 0
foreach ($f in $fixadosAchados) {
  try {
    $s = $shell.CreateShortcut($f.Caminho)
    $s.TargetPath = Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $s.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $atual 'BaixadorVideos.ps1') + '"'
    $s.WorkingDirectory = $atual
    if (Test-Path (Join-Path $atual $icone)) { $s.IconLocation = (Join-Path $atual $icone) }
    $s.Save(); $atualizados++
  } catch {}
}
if ($atualizados) { Write-Host "$atualizados atalho(s) fixado(s) atualizado(s) para a versão nova. Se o ícone parecer antigo, saia e entre no Windows de novo." -ForegroundColor Cyan }
Write-Host "Pronto: $apagados item(ns) antigo(s) apagado(s)." -ForegroundColor Green
exit 0
