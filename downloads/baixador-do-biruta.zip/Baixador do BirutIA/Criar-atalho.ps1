﻿param([string]$Pasta = $env:PASTA)
# Cria o atalho do Baixador na Área de Trabalho, com o nome e o ícone da marca (marca.json).
$pasta = ([IO.Path]::GetFullPath($Pasta)).TrimEnd('\')
$nome = 'Baixador'; $icone = 'icone.ico'
$arq = Join-Path $pasta 'marca.json'
if (Test-Path $arq) {
  try {
    $m = Get-Content $arq -Raw -Encoding UTF8 | ConvertFrom-Json
    if ($m.atalho) { $nome = $m.atalho } elseif ($m.nome) { $nome = $m.nome }
    if ($m.icone) { $icone = $m.icone }
  } catch {}
}
$nome = ($nome -replace '[\\/:*?"<>|]', '')
$destino = Join-Path ([Environment]::GetFolderPath('Desktop')) ($nome + '.lnk')
$s = (New-Object -ComObject WScript.Shell).CreateShortcut($destino)
$s.TargetPath = Join-Path $env:windir 'System32\WindowsPowerShell\v1.0\powershell.exe'
$s.Arguments = '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' + (Join-Path $pasta 'BaixadorVideos.ps1') + '"'
$s.WorkingDirectory = $pasta
$arqIcone = Join-Path $pasta $icone
if (Test-Path $arqIcone) { $s.IconLocation = $arqIcone }
$s.Save()
Write-Host "Atalho criado na Area de Trabalho: $nome"
