﻿Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$pasta = Join-Path $env:USERPROFILE 'Downloads'
$saida = Join-Path $env:TEMP 'baixador-saida.txt'
$erro  = Join-Path $env:TEMP 'baixador-erro.txt'
$env:PYTHONIOENCODING = 'utf-8'
$script:proc = $null

$form = New-Object Windows.Forms.Form
$form.Text = 'Baixador do BirutIA'
$form.ClientSize = New-Object Drawing.Size(540, 400)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.Font = New-Object Drawing.Font('Segoe UI', 10)

function Novo($tipo, $x, $y, $w, $h, $texto) {
  $c = New-Object "Windows.Forms.$tipo"
  $c.Location = New-Object Drawing.Point($x, $y)
  $c.Size = New-Object Drawing.Size($w, $h)
  if ($texto) { $c.Text = $texto }
  $form.Controls.Add($c)
  $c
}

$roxo   = [Drawing.Color]::FromArgb(98, 54, 199)
$laranja = [Drawing.Color]::FromArgb(255, 127, 0)
$form.BackColor = [Drawing.Color]::FromArgb(43, 45, 49)
$form.ForeColor = [Drawing.Color]::White

$logo    = Novo 'PictureBox' 205 8 130 130 ''
$logo.SizeMode = 'Zoom'
$arqLogo = Join-Path $PSScriptRoot 'cabeca.png'
if (Test-Path $arqLogo) { $logo.Image = [Drawing.Image]::FromFile($arqLogo) }
$titulo  = Novo 'Label' 20 140 500 32 'Baixador do BirutIA'
$titulo.TextAlign = 'MiddleCenter'; $titulo.Font = New-Object Drawing.Font('Segoe UI', 15, [Drawing.FontStyle]::Bold)
$rotulo  = Novo 'Label' 20 182 500 24 'Cole o link do vídeo (YouTube ou Instagram):'
$caixa   = Novo 'TextBox' 20 209 500 28 ''
$caixa.ForeColor = [Drawing.Color]::Black
$botao   = Novo 'Button' 20 249 500 42 'Baixar'
$barra   = Novo 'ProgressBar' 20 305 500 20 ''
$status  = Novo 'Label' 20 331 500 24 'Aguardando o link.'
$abrir   = Novo 'Button' 20 359 500 32 'Abrir pasta Downloads'
foreach ($b in $botao, $abrir) { $b.FlatStyle = 'Flat'; $b.FlatAppearance.BorderSize = 0; $b.ForeColor = [Drawing.Color]::White; $b.Cursor = 'Hand' }
$botao.BackColor = $roxo
$abrir.BackColor = $laranja
$botao.Font = New-Object Drawing.Font('Segoe UI', 12, [Drawing.FontStyle]::Bold)
$form.AcceptButton = $botao

$abrir.Add_Click({ Start-Process explorer.exe $pasta })

$timer = New-Object Windows.Forms.Timer
$timer.Interval = 500
$timer.Add_Tick({
  try {
    $linha = Get-Content $saida -Tail 1 -Encoding UTF8 -ErrorAction Stop
    if ($linha -match '(\d+(\.\d+)?)%') { $barra.Value = [Math]::Min(100, [int][double]$Matches[1]) }
  } catch {}
  if ($script:proc.HasExited) {
    $timer.Stop()
    $botao.Enabled = $true; $caixa.Enabled = $true
    if ($script:proc.ExitCode -eq 0) {
      $barra.Value = 100
      $status.Text = 'Pronto! O vídeo está na pasta Downloads.'
    } else {
      $msg = (Get-Content $erro -Tail 1 -Encoding UTF8 -ErrorAction SilentlyContinue)
      $status.Text = "Não foi possível baixar. $msg"
    }
  } else {
    $status.Text = 'Baixando na melhor qualidade... aguarde.'
  }
})

$botao.Add_Click({
  $link = $caixa.Text.Trim()
  if ($link -notmatch '^https?://') { $status.Text = 'Cole um link válido (começa com https://).'; return }
  $botao.Enabled = $false; $caixa.Enabled = $false
  $barra.Value = 0
  $status.Text = 'Iniciando...'
  $args = @('-S', 'res,ext:mp4:m4a', '--merge-output-format', 'mp4', '--windows-filenames', '--newline',
            '-P', "`"$pasta`"", '-o', '"%(title).80s.%(ext)s"', "`"$link`"")
  $script:proc = Start-Process yt-dlp -ArgumentList $args -WindowStyle Hidden -PassThru `
    -RedirectStandardOutput $saida -RedirectStandardError $erro
  $null = $script:proc.Handle # sem isso o PowerShell 5.1 devolve ExitCode vazio
  $timer.Start()
})

[void]$form.ShowDialog()
