﻿param([switch]$AutoTeste, [string]$LinkTeste = '', [string]$PastaTeste = '', [string]$ImagemTeste = '', [string]$ResultadoTeste = '')
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$env:PYTHONIOENCODING = 'utf-8'


# ---------- marca (nome, cores e logo) ----------
# Lê "marca.json", que fica na mesma pasta. Sem ele, usa a marca padrão (BirutIA).
$marca = [pscustomobject]@{ id = 'birutia'; nome = 'Baixador do BirutIA'; logo = 'cabeca.png'; icone = 'icone.ico'
  corPrincipal = @(98, 54, 199); corDestaque = @(255, 127, 0); corFundo = @(43, 45, 49) }
$arqMarca = Join-Path $PSScriptRoot 'marca.json'
if (Test-Path $arqMarca) {
  try {
    $m = Get-Content $arqMarca -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($k in 'id', 'nome', 'logo', 'icone', 'corPrincipal', 'corDestaque', 'corFundo') { if ($null -ne $m.$k) { $marca.$k = $m.$k } }
  } catch {}
}
function Cor($v) { [Drawing.Color]::FromArgb([int]$v[0], [int]$v[1], [int]$v[2]) }
function Texto-Sobre($v) { if ((0.299 * $v[0] + 0.587 * $v[1] + 0.114 * $v[2]) -gt 170) { [Drawing.Color]::FromArgb(30, 30, 30) } else { [Drawing.Color]::White } }

# ---------- configuração lembrada entre as aberturas ----------
$cfgDir = Join-Path $env:APPDATA ('Baixador-' + $marca.id)
if ($AutoTeste) { $cfgDir = Join-Path $env:TEMP 'baixador-teste-cfg' }
$cfgArq = Join-Path $cfgDir 'config.json'
$cfg = [pscustomobject]@{ pasta = (Join-Path $env:USERPROFILE 'Downloads'); formato = 'mp4'; fechar = $false; abrir = $true }
if (Test-Path $cfgArq) {
  try {
    $lido = Get-Content $cfgArq -Raw -Encoding UTF8 | ConvertFrom-Json
    foreach ($k in 'pasta', 'formato', 'fechar', 'abrir') { if ($null -ne $lido.$k) { $cfg.$k = $lido.$k } }
  } catch {}
}
if (-not (Test-Path $cfg.pasta)) { $cfg.pasta = Join-Path $env:USERPROFILE 'Downloads' }
function Salvar-Config { try { New-Item -ItemType Directory -Force $cfgDir | Out-Null; $cfg | ConvertTo-Json | Set-Content $cfgArq -Encoding UTF8 } catch {} }

$saida = Join-Path $env:TEMP "baixador-saida-$PID.txt"
$erro  = Join-Path $env:TEMP "baixador-erro-$PID.txt"
$script:proc = $null
$script:arquivo = ''
$script:cancelado = $false
$script:fechando = 0

# ---------- janela ----------
$roxo    = Cor $marca.corPrincipal
$laranja = Cor $marca.corDestaque
$chumbo  = Cor $marca.corFundo

$form = New-Object Windows.Forms.Form
$form.Text = $marca.nome
$form.ClientSize = New-Object Drawing.Size(560, 596)
$form.StartPosition = 'CenterScreen'
$form.FormBorderStyle = 'FixedDialog'
$form.MaximizeBox = $false
$form.Font = New-Object Drawing.Font('Segoe UI', 10)
$form.BackColor = $chumbo
$form.ForeColor = [Drawing.Color]::White
$arqIcone = Join-Path $PSScriptRoot $marca.icone
if (Test-Path $arqIcone) { try { $form.Icon = New-Object Drawing.Icon($arqIcone) } catch {} }

function Novo($tipo, $x, $y, $w, $h, $texto) {
  $c = New-Object "Windows.Forms.$tipo"
  $c.Location = New-Object Drawing.Point($x, $y)
  $c.Size = New-Object Drawing.Size($w, $h)
  if ($texto) { $c.Text = $texto }
  $form.Controls.Add($c)
  $c
}
function Estilo-Botao($b, $cor) {
  $b.FlatStyle = 'Flat'; $b.FlatAppearance.BorderSize = 0; $b.ForeColor = (Texto-Sobre @($cor.R, $cor.G, $cor.B))
  $b.BackColor = $cor; $b.Cursor = 'Hand'
}

$logo = Novo 'PictureBox' 120 6 320 110 ''
$logo.SizeMode = 'Zoom'
$arqLogo = Join-Path $PSScriptRoot $marca.logo
if (Test-Path $arqLogo) { $logo.Image = [Drawing.Image]::FromFile($arqLogo) }

$titulo = Novo 'Label' 20 118 520 32 $marca.nome
$titulo.TextAlign = 'MiddleCenter'; $titulo.Font = New-Object Drawing.Font('Segoe UI', 15, [Drawing.FontStyle]::Bold)

$rotulo = Novo 'Label' 20 156 520 22 'Cole o link do vídeo (YouTube ou Instagram):'
$caixa  = Novo 'TextBox' 20 182 420 28 ''
$caixa.ForeColor = [Drawing.Color]::Black
$colar  = Novo 'Button' 448 181 92 30 'Colar'
Estilo-Botao $colar $roxo

$rotPasta = Novo 'Label' 20 220 520 22 'Salvar em:'
$lblPasta = Novo 'Label' 20 244 420 28 ''
$lblPasta.AutoEllipsis = $true; $lblPasta.TextAlign = 'MiddleLeft'
$lblPasta.BackColor = [Drawing.Color]::FromArgb(58, 61, 68); $lblPasta.Padding = New-Object Windows.Forms.Padding(6, 0, 0, 0)
$escolher = Novo 'Button' 448 243 92 30 'Escolher...'
Estilo-Botao $escolher $roxo

$rotForm = Novo 'Label' 20 286 80 24 'Formato:'
$rotForm.TextAlign = 'MiddleLeft'
$combo = Novo 'ComboBox' 100 284 260 28 ''
$combo.DropDownStyle = 'DropDownList'
[void]$combo.Items.Add('Vídeo (MP4), melhor qualidade')
[void]$combo.Items.Add('Só o áudio (MP3)')
$combo.ForeColor = [Drawing.Color]::Black

$chkFechar = Novo 'CheckBox' 20 322 520 26 'Fechar o programa quando terminar'
$chkAbrir  = Novo 'CheckBox' 20 348 520 26 'Mostrar o arquivo na pasta quando terminar'
foreach ($c in $chkFechar, $chkAbrir) { $c.ForeColor = [Drawing.Color]::White }

$botao    = Novo 'Button' 20 384 410 46 'Baixar'
$cancelar = Novo 'Button' 438 384 102 46 'Cancelar'
Estilo-Botao $botao $roxo
Estilo-Botao $cancelar ([Drawing.Color]::FromArgb(120, 50, 55))
$botao.Font = New-Object Drawing.Font('Segoe UI', 12, [Drawing.FontStyle]::Bold)
$cancelar.Enabled = $false
$form.AcceptButton = $botao

$barra = Novo 'ProgressBar' 20 442 470 24 ''
$lblPct = Novo 'Label' 494 442 46 24 '0%'
$lblPct.TextAlign = 'MiddleRight'; $lblPct.Font = New-Object Drawing.Font('Segoe UI', 10, [Drawing.FontStyle]::Bold)
$status = Novo 'Label' 20 472 520 66 'Aguardando o link.'

$abrir = Novo 'Button' 20 548 520 32 'Abrir a pasta'
Estilo-Botao $abrir $laranja

# valores iniciais
$lblPasta.Text = $cfg.pasta
$combo.SelectedIndex = $(if ($cfg.formato -eq 'mp3') { 1 } else { 0 })
$chkFechar.Checked = [bool]$cfg.fechar
$chkAbrir.Checked = [bool]$cfg.abrir

function Guardar-Opcoes {
  $cfg.formato = $(if ($combo.SelectedIndex -eq 1) { 'mp3' } else { 'mp4' })
  $cfg.fechar = $chkFechar.Checked
  $cfg.abrir = $chkAbrir.Checked
  Salvar-Config
}
$combo.Add_SelectedIndexChanged({ Guardar-Opcoes })
$chkFechar.Add_CheckedChanged({ Guardar-Opcoes })
$chkAbrir.Add_CheckedChanged({ Guardar-Opcoes })

$colar.Add_Click({
  $t = [Windows.Forms.Clipboard]::GetText()
  if ($t) { $caixa.Text = $t.Trim(); $status.Text = 'Link colado. Clique em Baixar.' } else { $status.Text = 'Não há nenhum link copiado.' }
})
$escolher.Add_Click({
  $d = New-Object Windows.Forms.FolderBrowserDialog
  $d.Description = 'Escolha a pasta onde os vídeos serão salvos'
  $d.SelectedPath = $cfg.pasta
  $d.ShowNewFolderButton = $true
  if ($d.ShowDialog() -eq 'OK') { $cfg.pasta = $d.SelectedPath; $lblPasta.Text = $cfg.pasta; Salvar-Config }
})
$abrir.Add_Click({ Start-Process explorer.exe "`"$($cfg.pasta)`"" })

# tradução das mensagens de erro mais comuns
function Erro-Amigavel($texto) {
  if ($texto -match 'Private video|Sign in|login required|rate-limit|Requested content is not available') { return 'O vídeo é privado ou exige login. Só é possível baixar vídeos públicos.' }
  if ($texto -match 'Unsupported URL') { return 'Esse endereço não é de um vídeo. Confira o link.' }
  if ($texto -match 'Unexpected response|impersonat|extractor') { return 'O site respondeu de um jeito inesperado. Esta janela é para YouTube e Instagram; se o link for de um deles, atualize o programa de download e tente de novo.' }
  if ($texto -match 'HTTP Error 403|HTTP Error 429') { return 'O site bloqueou o download agora. Tente de novo em alguns minutos.' }
  if ($texto -match 'Video unavailable|unavailable') { return 'O vídeo não está disponível.' }
  if ($texto -match 'ffmpeg') { return 'Falta o ffmpeg. Rode de novo o instalador.' }
  if ($texto -match 'Unable to download webpage|getaddrinfo|Temporary failure|timed out') { return 'Não foi possível acessar o site. Confira a internet.' }
  return $texto
}

function Finalizar($ok) {
  $botao.Enabled = $true; $caixa.Enabled = $true; $colar.Enabled = $true; $escolher.Enabled = $true; $combo.Enabled = $true
  $cancelar.Enabled = $false
  if ($script:cancelado) { $status.Text = 'Download cancelado.'; $barra.Value = 0; $lblPct.Text = '0%'; return }
  if ($ok) {
    $barra.Value = 100; $lblPct.Text = '100%'
    $nome = if ($script:arquivo) { Split-Path $script:arquivo -Leaf } else { '' }
    $status.Text = $(if ($nome) { "Pronto! Salvo como:`n$nome" } else { 'Pronto! O arquivo está na pasta escolhida.' })
    if ($chkAbrir.Checked) {
      if ($script:arquivo -and (Test-Path -LiteralPath $script:arquivo)) { Start-Process explorer.exe "/select,`"$script:arquivo`"" } else { Start-Process explorer.exe "`"$($cfg.pasta)`"" }
    }
    if ($chkFechar.Checked) { $script:fechando = 3; $status.Text += "`nFechando em 3 segundos..." }
  } else {
    $msg = ''
    try {
      $todas = @(Get-Content $erro -Encoding UTF8 -ErrorAction Stop) + @(Get-Content $saida -Encoding UTF8 -ErrorAction SilentlyContinue)
      $erros = @($todas | Where-Object { $_ -match '^ERROR' })
      $msg = $(if ($erros.Count) { ($erros | Select-Object -Last 1) -replace '^ERROR:\s*(\[[^\]]+\]\s*)?(\S+:\s*)?', '' } else { ($todas | Where-Object { $_.Trim() } | Select-Object -Last 2) -join ' ' })
    } catch {}
    $amigavel = Erro-Amigavel $msg
    if ($amigavel.Length -gt 140) { $amigavel = $amigavel.Substring(0, 140) + '...' }
    $status.Text = 'Não foi possível baixar. ' + $amigavel
    $barra.Value = 0; $lblPct.Text = '0%'
  }
}

$timer = New-Object Windows.Forms.Timer
$timer.Interval = 400
$timer.Add_Tick({
  if ($script:fechando -gt 0) {
    $script:fechando -= 0.4
    if ($script:fechando -le 0) { $timer.Stop(); $form.Close() }
    return
  }
  if ($null -eq $script:proc) { return }
  $linhas = @()
  try { $linhas = @(Get-Content $saida -Encoding UTF8 -ErrorAction Stop) } catch {}
  $partes = 1; $idx = 0; $pct = 0.0; $vel = ''; $eta = ''; $final = $false; $existe = $false
  foreach ($l in $linhas) {
    if ($l -match 'Downloading \d+ format\(s\): (\S+)') { $partes = ($Matches[1] -split '\+').Count }
    if ($l -match '^\[download\] Destination:') { $idx++; $pct = 0.0 }
    if ($l -match '^\[download\]\s+(\d+(\.\d+)?)%') {
      $pct = [double]$Matches[1]
      $vel = ''; $eta = ''
      if ($l -match ' at\s+(\S+/s)') { $vel = $Matches[1] }
      if ($l -match 'ETA\s+(\S+)') { $eta = $Matches[1] }
    }
    if ($l -match '^\[(Merger|ExtractAudio|VideoConvertor|Fixup\w*|MoveFiles)\]') { $final = $true }
    if ($l -match 'has already been downloaded') { $existe = $true }
  }
  $total = 0.0
  if ($idx -ge 1) { $total = (([Math]::Min($idx, $partes) - 1) + ($pct / 100.0)) / $partes * 100.0 }
  if ($final) { $total = 99.0 }
  $v = [Math]::Max(0, [Math]::Min(100, [int][Math]::Floor($total)))
  if (-not $script:proc.HasExited) {
    $barra.Value = $v; $lblPct.Text = "$v%"
    if ($final) { $status.Text = 'Finalizando o arquivo...' }
    else {
      $extra = ''
      if ($vel) { $extra += "  $vel" }
      if ($eta) { $extra += "  faltam $eta" }
      $status.Text = "Baixando $v%$extra"
    }
  } else {
    $timer.Stop()
    foreach ($l in $linhas) { $t = $l.Trim(); if ($t -and ($t -notmatch '^\[') -and ($t -match '^[A-Za-z]:\\') -and (Test-Path -LiteralPath $t)) { $script:arquivo = $t } }
    $ok = ($script:proc.ExitCode -eq 0) -and (-not $script:cancelado)
    Finalizar $ok
    if ($existe -and $ok) { $status.Text = "Esse vídeo já estava na pasta.`n" + (Split-Path $script:arquivo -Leaf) }
    if ($script:fechando -gt 0) { $timer.Start() }
  }
})

$cancelar.Add_Click({
  if ($script:proc -and -not $script:proc.HasExited) {
    $script:cancelado = $true
    try { & taskkill /PID $script:proc.Id /T /F | Out-Null } catch {}
  }
})

$botao.Add_Click({
  $link = $caixa.Text.Trim()
  if ($link -notmatch '^https?://') { $status.Text = 'Cole um link válido (começa com https://).'; return }
  if (-not (Test-Path $cfg.pasta)) { $status.Text = 'A pasta escolhida não existe mais. Clique em Escolher.'; return }
  Guardar-Opcoes
  $botao.Enabled = $false; $caixa.Enabled = $false; $colar.Enabled = $false; $escolher.Enabled = $false; $combo.Enabled = $false
  $cancelar.Enabled = $true
  $script:cancelado = $false; $script:arquivo = ''
  $barra.Value = 0; $lblPct.Text = '0%'
  $status.Text = 'Iniciando...'
  Remove-Item $saida, $erro -ErrorAction SilentlyContinue
  $p = $cfg.pasta; if ($p.EndsWith('\')) { $p += '\' }
  $a = @('--no-playlist', '--windows-filenames', '--trim-filenames', '150', '--newline', '--no-mtime', '--no-quiet',
         '--print', 'after_move:filepath', '-P', "`"$p`"", '-o', '"%(title)s.%(ext)s"')
  if ($cfg.formato -eq 'mp3') { $a += @('-x', '--audio-format', 'mp3', '--audio-quality', '0') }
  else { $a += @('-S', 'res,ext:mp4:m4a', '--merge-output-format', 'mp4') }
  $a += "`"$link`""
  try {
    $script:proc = Start-Process yt-dlp -ArgumentList $a -WindowStyle Hidden -PassThru -RedirectStandardOutput $saida -RedirectStandardError $erro
    $null = $script:proc.Handle # sem isso o PowerShell 5.1 devolve ExitCode vazio
    $timer.Start()
  } catch {
    $status.Text = 'Não foi possível iniciar o download. Rode de novo o instalador.'
    $botao.Enabled = $true; $caixa.Enabled = $true; $colar.Enabled = $true; $escolher.Enabled = $true; $combo.Enabled = $true; $cancelar.Enabled = $false
  }
})

$form.Add_FormClosing({
  if ($script:proc -and -not $script:proc.HasExited) { try { & taskkill /PID $script:proc.Id /T /F | Out-Null } catch {} }
  Remove-Item $saida, $erro -ErrorAction SilentlyContinue
})

# ao abrir: se há um link copiado, já deixa preenchido
$form.Add_Shown({
  if (-not $AutoTeste) {
    try {
      $t = [Windows.Forms.Clipboard]::GetText()
      if ($t -and $t.Trim() -match '^https?://\S+$' -and -not $caixa.Text) { $caixa.Text = $t.Trim(); $status.Text = 'Link encontrado na área de transferência. Clique em Baixar.' }
    } catch {}
  }
  $caixa.Focus()
})

# ---------- modo de teste (usado só para conferir o programa) ----------
if ($AutoTeste) {
  $tt = New-Object Windows.Forms.Timer
  $tt.Interval = 500
  $script:fase = 0; $script:espera = 0
  $tt.Add_Tick({
    $script:espera += 0.5
    if ($script:fase -eq 0) {
      if ($LinkTeste) { $caixa.Text = $LinkTeste; if ($PastaTeste) { $cfg.pasta = $PastaTeste; $lblPasta.Text = $PastaTeste }; $botao.PerformClick(); $script:fase = 1 }
      else { $script:fase = 2 }
    } elseif ($script:fase -eq 1) {
      if ($ImagemTeste -and $script:espera -ge 6 -and $script:espera -lt 6.6) {
        $b = New-Object Drawing.Bitmap($form.Width, $form.Height); $form.DrawToBitmap($b, (New-Object Drawing.Rectangle(0, 0, $form.Width, $form.Height))); $b.Save($ImagemTeste.Replace('.png', '-meio.png')); $b.Dispose()
      }
      if ($script:proc -and $script:proc.HasExited -and $timer.Enabled -eq $false -or $script:espera -gt 240) { $script:fase = 2; $script:espera = 0 }
    } elseif ($script:fase -eq 2) {
      if ($script:espera -ge 1) {
        if ($ImagemTeste) { $b = New-Object Drawing.Bitmap($form.Width, $form.Height); $form.DrawToBitmap($b, (New-Object Drawing.Rectangle(0, 0, $form.Width, $form.Height))); $b.Save($ImagemTeste); $b.Dispose() }
        if ($ResultadoTeste) { @{ arquivo = $script:arquivo; status = $status.Text; pct = $lblPct.Text; formato = $cfg.formato } | ConvertTo-Json | Set-Content $ResultadoTeste -Encoding UTF8 }
        $tt.Stop(); $chkFechar.Checked = $false; $script:fechando = 0; $form.Close()
      }
    }
  })
  $tt.Start()
}

[void]$form.ShowDialog()
