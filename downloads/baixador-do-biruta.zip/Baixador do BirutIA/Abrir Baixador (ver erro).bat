@echo off
chcp 65001 >nul
echo Abrindo o Baixador... (se aparecer uma mensagem vermelha, tire uma foto e envie)
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BaixadorVideos.ps1"
echo.
echo Fim. Se nada abriu, tire uma foto desta tela.
pause
