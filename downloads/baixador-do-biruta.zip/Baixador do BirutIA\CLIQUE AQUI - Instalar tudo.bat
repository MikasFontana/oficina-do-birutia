@echo off
chcp 65001 >nul
title Instalando o Baixador do BirutIA
echo.
echo ================================================
echo   Baixador do BirutIA : instalacao completa (so uma vez)
echo ================================================
echo.
echo Este instalador faz tudo sozinho: remove a versao antiga, instala a nova
echo e deixa o atalho na Area de Trabalho. Pode levar alguns minutos.
echo (se o Windows perguntar algo, clique em Sim)
echo.
set "ORIGEM=%~dp0"
echo "%ORIGEM%" | findstr /I /C:".zip" >nul && (
  echo ATENCAO: voce abriu este arquivo de dentro do ZIP.
  echo Feche esta janela, clique com o botao direito no ZIP, escolha "Extrair tudo"
  echo e depois de dois cliques neste arquivo, na pasta extraida.
  echo.
  pause
  exit /b 1
)
set "DEST=%USERPROFILE%\Baixador do BirutIA"

echo [1/4] Copiando o programa para %DEST% ...
if /I not "%ORIGEM%"=="%DEST%\" (
  robocopy "%ORIGEM%." "%DEST%" /E /NFL /NDL /NJH /NJS /XF "CLIQUE AQUI*.bat" >nul
  if errorlevel 8 ( echo Nao consegui copiar os arquivos. & pause & exit /b 1 )
)

echo.
echo [2/4] Instalando as ferramentas de download (yt-dlp e ffmpeg)...
if not defined BAIXADOR_SEM_WINGET (
  where winget >nul 2>&1 || ( echo O instalador de programas do Windows ^(winget^) nao foi encontrado. Atualize o Windows ou peca ajuda. & pause & exit /b 1 )
  winget install -e --id yt-dlp.yt-dlp --accept-source-agreements --accept-package-agreements
  winget upgrade -e --id yt-dlp.yt-dlp --accept-source-agreements --accept-package-agreements
  winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
)

echo.
echo [3/4] Procurando e removendo versoes antigas do Baixador (os seus videos nao sao mexidos)...
set "PASTA=%DEST%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%DEST%\Limpar-instalacoes-antigas.ps1" -SemPerguntar

echo.
echo [4/4] Criando o atalho na Area de Trabalho...
powershell -NoProfile -ExecutionPolicy Bypass -File "%DEST%\Criar-atalho.ps1"

echo.
echo ================================================
echo   Pronto! Use o atalho na Area de Trabalho.
echo   (Nao mova nem apague a pasta %DEST%)
echo ================================================
echo Abrindo o programa...
start "" powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%DEST%\BaixadorVideos.ps1"
echo.
pause